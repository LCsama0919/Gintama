
   const video = document.getElementById('intro-video');
   const playPrompt = document.getElementById('play-prompt');
   const skipButton = document.getElementById('skip-button');
   const videoContainer = document.getElementById('video-container');
   const mainContent = document.getElementById('main-content');

   const playPromise = video.play();

   if (playPromise!== undefined) {
       playPromise.then(() => {
           playPrompt.style.display = 'none';
           skipButton.style.display = 'block';
       }).catch(() => {
           playPrompt.style.display = 'block';
           document.addEventListener('click', () => {
               video.play();
               playPrompt.style.display = 'none';
               skipButton.style.display = 'block';
           });
       });
   }

   video.addEventListener('pause', function () {
       video.play();
   });


   video.addEventListener('ended', function () {

       videoContainer.style.display = 'none';
       mainContent.style.display = 'block';
   });

   skipButton.addEventListener('click', function () {
       video.pause();
       videoContainer.style.display = 'none';
       mainContent.style.display = 'block';
   });

    document.addEventListener('DOMContentLoaded', function () {
    const navButtons = document.querySelectorAll('.vertical-nav .nav-item'); 
    const imageDisplay = document.getElementById('image-display'); 
    
    navButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        const imgPath = button.getAttribute('data-img'); 
        imageDisplay.innerHTML = `<img src="${imgPath}" alt="展示图片">`; 
      });
    });
  });